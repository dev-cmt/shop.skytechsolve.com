<x-backend-layout title="Tags Management">
    <!-- Page Header -->
    <div class="d-md-flex d-block align-items-center justify-content-between my-4 page-header-breadcrumb">
        <h1 class="page-title fw-semibold fs-18 mb-0">Add New Product</h1>
        <div class="ms-md-1 ms-0">
            <nav>
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('products.index') }}">Products</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Add New</li>
                </ol>
            </nav>
        </div>
    </div>

    <form action="{{ route('products.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="row">
            <!-- Left Column: Basic Info + SEO + Discounts -->
            <div class="col-md-8">

                <!-- Basic Information -->
                <div class="card custom-card">
                    <div class="card-header">
                        <div class="card-title">Basic Information</div>
                    </div>
                    <div class="card-body">
                        <div class="mb-2">
                            <label for="name" class="form-label">Product Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="name" name="name" value="{{ old('name') }}" required>
                            @error('name') <div class="text-danger mt-1">{{ $message }}</div> @enderror
                        </div>

                        <div class="mb-2">
                            <label for="description" class="form-label">Description</label>
                            <textarea name="description" id="description" class="form-control summernote" rows="4">{!! old('description') !!}</textarea>
                            @error('description') <div class="text-danger mt-1">{{ $message }}</div> @enderror
                        </div>
                    </div>
                </div>

                <!-- Others Information -->
                <div class="card custom-card">
                    <div class="card-header">
                        <div class="card-title">
                            Others Information
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-xl-2">
                                <nav class="nav nav-tabs flex-column nav-style-4" role="tablist">
                                    <a class="nav-link active" data-bs-toggle="tab" role="tab" aria-current="page" href="#home-vertical-link" aria-selected="false">
                                        <i class="ri-home-smile-line me-2 align-middle d-inline-block"></i> Inventory
                                    </a>
                                    <a class="nav-link" data-bs-toggle="tab" role="tab" aria-current="page" href="#services-vertical-link" aria-selected="true">
                                        <i class="ri-coupon-line me-2 align-middle d-inline-block"></i> Discounts
                                    </a>
                                    <a class="nav-link" data-bs-toggle="tab" role="tab" aria-current="page" href="#about-vertical-link" aria-selected="false">
                                        <i class="ri-ship-line me-2 align-middle d-inline-block"></i> Shipping
                                    </a>
                                    <a class="nav-link" data-bs-toggle="tab" role="tab" aria-current="page" href="#contacts-vertical-link" aria-selected="false">
                                        <i class="ri-search-eye-line me-2 align-middle d-inline-block"></i> SEO Info.
                                    </a>
                                </nav>
                            </div>
                            <div class="col-xl-10">
                                <div class="tab-content">
                                    <div class="tab-pane show active text-muted" id="home-vertical-link" role="tabpanel">
                                        <div class="row">
                                            <div class="col-md-6 mb-1">
                                                <label class="form-label">SKU Prefix <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control form-control-sm" id="sku_prefix" name="sku_prefix" value="{{ old('sku_prefix','PROD') }}">
                                                @error('total_stock') <div class="text-danger mt-1">{{ $message }}</div> @enderror
                                            </div>
                                            <div class="col-md-6 mb-1">
                                                <label class="form-label">Base Price <span class="text-danger">*</span></label>
                                                <input type="number" class="form-control form-control-sm" id="price" name="price" value="{{ old('price','0.00') }}" min="0" step="0.01">
                                                @error('price') <div class="text-danger mt-1">{{ $message }}</div> @enderror
                                            </div>
                                            <div class="col-md-6 mb-1">
                                                <label for="purchase_price" class="form-label">Purchase Price</label>
                                                <input type="number" class="form-control form-control-sm" id="purchase_price" name="purchase_price" value="{{ old('purchase_price') }}" required>
                                                @error('purchase_price') <div class="text-danger mt-1">{{ $message }}</div> @enderror
                                            </div>
                                            <div class="col-md-6 mb-1">
                                                <label for="base_price" class="form-label">Stock Management <span class="text-danger">*</span></label>
                                                <select name="discount_type" id="discount_type" class="form-select">
                                                    <option value="7 Day" {{ old('discount_type')=='percentage'?'selected':'' }}>Quantity</option>
                                                    <option value="flat" {{ old('discount_type')=='flat'?'selected':'' }}>In Stock</option>
                                                    <option value="flat" {{ old('discount_type')=='flat'?'selected':'' }}>Out Of Stock</option>
                                                    <option value="flat" {{ old('discount_type')=='flat'?'selected':'' }}>Upcomming</option>
                                                </select>
                                                @error('base_price') <div class="text-danger mt-1">{{ $message }}</div> @enderror
                                            </div>
                                            <div class="col-md-6 mb-1">
                                                <label for="total_stock" class="form-label">Total Stock</label>
                                                <input type="number" class="form-control form-control-sm" id="total_stock" name="total_stock" value="{{ old('total_stock', 0) }}">
                                                @error('total_stock') <div class="text-danger mt-1">{{ $message }}</div> @enderror
                                            </div>
                                            <div class="col-md-6 mb-1">
                                                <label for="stock_out" class="form-label">Stock Out <span class="text-danger">*</span></label>
                                                <input type="number" class="form-control form-control-sm" id="stock_out" name="stock_out" value="{{ old('stock_out', 1) }}" required>
                                                @error('base_price') <div class="text-danger mt-1">{{ $message }}</div> @enderror
                                            </div>
                                            <div class="col-md-6 mb-1">
                                                <label for="base_price" class="form-label">Alert Quantity</label>
                                                <input type="number" class="form-control form-control-sm" id="base_price" name="base_price" value="{{ old('base_price') }}" required>
                                                @error('base_price') <div class="text-danger mt-1">{{ $message }}</div> @enderror
                                            </div>
                                            <div class="col-md-6 mb-1">
                                                <label for="base_price" class="form-label">Expire</label>
                                                <select name="discount_type" id="discount_type" class="form-select">
                                                    <option value="">Select</option>
                                                    <option value="7 Day" {{ old('discount_type')=='percentage'?'selected':'' }}>7 Days</option>
                                                    <option value="flat" {{ old('discount_type')=='flat'?'selected':'' }}>15 Days</option>
                                                    <option value="flat" {{ old('discount_type')=='flat'?'selected':'' }}>1 Month</option>
                                                    <option value="flat" {{ old('discount_type')=='flat'?'selected':'' }}>2 Month</option>
                                                    <option value="flat" {{ old('discount_type')=='flat'?'selected':'' }}>3 Month</option>
                                                    <option value="flat" {{ old('discount_type')=='flat'?'selected':'' }}>6 Month</option>
                                                    <option value="flat" {{ old('discount_type')=='flat'?'selected':'' }}>1 Year</option>
                                                    <option value="flat" {{ old('discount_type')=='flat'?'selected':'' }}>2 Year</option>
                                                    <option value="flat" {{ old('discount_type')=='flat'?'selected':'' }}>3 Year</option>
                                                    <option value="flat" {{ old('discount_type')=='flat'?'selected':'' }}>5 Year</option>
                                                    <option value="flat" {{ old('discount_type')=='flat'?'selected':'' }}>10 Year</option>
                                                    <option value="flat" {{ old('discount_type')=='flat'?'selected':'' }}>Life Time</option>
                                                </select>
                                                @error('base_price') <div class="text-danger mt-1">{{ $message }}</div> @enderror
                                            </div>
                                        </div>

                                    </div>
                                    <div class="tab-pane text-muted" id="services-vertical-link" role="tabpanel">
                                        <div class="row">
                                            <div class="col-md-6 mb-2">
                                                <label for="discount_type" class="form-label">Discount Type</label>
                                                <select name="discount_type" id="discount_type" class="form-select">
                                                    <option value="">Select Type</option>
                                                    <option value="percentage" {{ old('discount_type')=='percentage'?'selected':'' }}>Percentage</option>
                                                    <option value="flat" {{ old('discount_type')=='flat'?'selected':'' }}>Flat</option>
                                                </select>
                                            </div>
                                            <div class="col-md-6 mb-2">
                                                <label for="discount_amount" class="form-label">Amount</label>
                                                <input type="number" class="form-control form-control-sm" id="discount_amount" name="discount_amount" value="{{ old('discount_amount') }}">
                                            </div>
                                            <div class="col-md-6 mb-2">
                                                <label for="discount_start" class="form-label">Start Date</label>
                                                <input type="date" class="form-control" id="discount_start" name="discount_start" value="{{ old('discount_start') }}">
                                            </div>
                                            <div class="col-md-6 mb-2">
                                                <label for="discount_end" class="form-label">End Date</label>
                                                <input type="date" class="form-control" id="discount_end" name="discount_end" value="{{ old('discount_end') }}">
                                            </div>
                                            <!-- Discount Status -->
                                            <div class="mt-4 border-top pt-3">
                                                <div class="form-check form-switch">
                                                    <input class="form-check-input" name="discount_status" type="checkbox" id="discountStatusToggle">
                                                    <label class="form-check-label" for="discountStatusToggle">Enable Discount</label>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="tab-pane text-muted" id="about-vertical-link" role="tabpanel">
                                        <!-- Weight -->
                                        <div class="mb-2">
                                            <label for="weight" class="form-label">Weight (kg)</label>
                                            <input type="number" class="form-control" id="weight" name="weight" value="{{ old('weight', 0) }}" step="0.01" min="0">
                                            @error('weight') <div class="text-danger mt-1">{{ $message }}</div> @enderror
                                        </div>
                                        <div class="border p-1 mb-2 bg-light">
                                            <label class="form-label mb-2 d-block">Dimensions (cm)</label>
                                            <div class="row g-2">
                                                <div class="col-md-4">
                                                    <input type="number" class="form-control" id="length" name="length" placeholder="Length" value="{{ old('length') }}" step="0.01" min="0">
                                                </div>
                                                <div class="col-md-4">
                                                    <input type="number" class="form-control" id="width" name="width" placeholder="Width" value="{{ old('width') }}" step="0.01" min="0">
                                                </div>
                                                <div class="col-md-4">
                                                    <input type="number" class="form-control" id="height" name="height" placeholder="Height" value="{{ old('height') }}" step="0.01" min="0">
                                                </div>
                                            </div>
                                            @if($errors->has('length') || $errors->has('width') || $errors->has('height'))
                                                <div class="text-danger mt-1">Please check all dimension fields.</div>
                                            @endif
                                        </div>
                                        <div class="row">
                                            <div class="col-6">
                                                <label class="form-label">Shipping Class</label>
                                                <select id="shipping_class" class="form-select">
                                                    <option value="">Select Shipping Class</option>
                                                    @foreach($shippingClasses ?? [] as $class)
                                                        <option value="{{ $class->id }}" data-inside="{{ $class->inside_rate }}" data-outside="{{ $class->outside_rate }}"
                                                            {{ old('shipping_class') == $class->id ? 'selected' : '' }}>
                                                            {{ $class->name }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="col-3">
                                                <label class="form-label">Inside City Rate</label>
                                                <input type="text" id="inside_rate_display" class="form-control form-control-sm" readonly>
                                            </div>
                                            <div class="col-3">
                                                <label class="form-label">Outside City Rate</label>
                                                <input type="text" id="outside_rate_display" class="form-control form-control-sm" readonly>
                                            </div>
                                        </div>

                                        <script>
                                            const s=document.getElementById('shipping_class'),i=document.getElementById('inside_rate_display'),o=document.getElementById('outside_rate_display');
                                            function u(){const e=s.selectedOptions[0];i.value=`৳ ${e?.dataset.inside||0}`,o.value=`৳ ${e?.dataset.outside||0}`}
                                            s.addEventListener('change',u),u();
                                        </script>
                                    </div>
                                    <div class="tab-pane text-muted" id="contacts-vertical-link" role="tabpanel">
                                        <div class="mb-1">
                                            <label for="meta_title" class="form-label">Meta Title</label>
                                            <input type="text" class="form-control" id="meta_title" name="meta_title" value="{{ old('meta_title') }}">
                                            @error('meta_title') <div class="text-danger mt-1">{{ $message }}</div> @enderror
                                        </div>
                                        <div class="mb-1">
                                            <label for="meta_description" class="form-label">Meta Description</label>
                                            <textarea class="form-control" id="meta_description" name="meta_description" rows="2">{{ old('meta_description') }}</textarea>
                                            @error('meta_description') <div class="text-danger mt-1">{{ $message }}</div> @enderror
                                        </div>
                                        <div class="mb-1">
                                            <label for="meta_keywords" class="form-label">Meta Keywords</label>
                                            <input type="text" class="form-control" id="meta_keywords" name="meta_keywords" value="{{ old('meta_keywords') }}" placeholder="Separate keywords with commas">
                                            @error('meta_keywords') <div class="text-danger mt-1">{{ $message }}</div> @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Product Variants -->
                <div class="card custom-card">
                    <div class="card-header">
                        <div class="card-title">Product Variants Preview</div>
                    </div>

                    <div class="card-body">
                        <div class="row mb-3">
                            <div class="col-md-4">
                                <label class="form-label">Attributes</label>
                                <select name="attribute_id[]" id="attribute_id" class="form-select" multiple>
                                    @foreach($attributes as $attribute)
                                        <option value="{{ $attribute->id }}">{{ $attribute->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            {{-- <div class="col-md-4">
                                <label class="form-label">SKU Prefix</label>
                                <input type="text" id="sku_prefix" class="form-control" placeholder="SKU" value="SKU">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Base Price</label>
                                <input type="number" id="price" class="form-control" placeholder="0.00" value="0.00">
                            </div> --}}
                        </div>

                        <div id="attribute_items_container" class="row"></div>

                        <div id="variant_combinations_container"></div>
                    </div>
                </div>

                @push('css')
                <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/choices.js/public/assets/styles/choices.min.css" />
                @endpush

                @push('js')
                <script src="https://cdn.jsdelivr.net/npm/choices.js/public/assets/scripts/choices.min.js"></script>
                <script>
                    $(function() {

                        // Initialize Choices.js dropdowns
                        function initChoices() {
                            const makeChoice = (el) => new Choices(el, {
                                removeItemButton: true,
                                searchEnabled: true,
                                placeholderValue: 'Select Items'
                            });

                            if (!$('#attribute_id').data('choices-initialized')) {
                                makeChoice('#attribute_id');
                                $('#attribute_id').data('choices-initialized', true);
                            }

                            $('.attribute-item').each(function() {
                                if (!$(this).data('choices-initialized')) {
                                    makeChoice(this);
                                    $(this).data('choices-initialized', true);
                                }
                            });
                        }


                        // Load attribute items (e.g. Color, Size options)
                        function loadAttributeItems() {
                            let selected = $('#attribute_id').val();
                            if (!selected || selected.length === 0) {
                                $('#attribute_items_container').html('');
                                $('#variant_combinations_container').html('');
                                return;
                            }

                            $.get('{{ route("attributes.getItems") }}', { attribute_ids: selected }, function(html) {
                                $('#attribute_items_container').html(html);
                                initChoices();
                            });
                        }

                        // Load variant combinations (SKU generation)
                        function loadVariantCombinations() {
                            let attrs = [];
                            $('.attribute-item').each(function() {
                                let id = $(this).data('id');
                                let items = $(this).val();
                                if (items && items.length) attrs.push({ id, items });
                            });

                            $.ajax({
                                url: '{{ route("products.getItemsCombo") }}',
                                method: 'GET',
                                data: {
                                    sku_prefix: $('#sku_prefix').val(),
                                    price: $('#price').val(),
                                    purchase_price: $('#purchase_price').val(),
                                    attributes: attrs
                                },
                                success: function(html) {
                                    $('#variant_combinations_container').html(html);
                                }
                            });
                        }

                        // ✅ NEW: Dynamically show file inputs for color/image attributes
                        function updateImageUploadFields() {
                            $('.attribute-item').each(function() {
                                let hasImage = $(this).data('has-image'); // detect attribute with images (Color)
                                if (!hasImage) return;

                                let attrId = $(this).data('id');
                                let selectedItems = $(this).find('option:selected');
                                let container = $('.image-upload-container[data-attr-id="' + attrId + '"] .image-upload-fields');

                                container.html(''); // Clear previous fields

                                selectedItems.each(function() {
                                    let itemId = $(this).val();
                                    let itemName = $(this).text();

                                    // Add file upload input per selected item
                                    let fieldHtml = `
                                        <div class="d-flex align-items-center mb-2 single-upload-field" data-item-id="${itemId}">
                                            <span class="me-2 fw-semibold text-secondary" style="min-width:80px">${itemName}</span>
                                            <input type="file" name="attribute_images[${attrId}][${itemId}]" class="form-control form-control-sm" accept="image/*">
                                        </div>
                                    `;
                                    container.append(fieldHtml);
                                });
                            });
                        }

                        // --------------------
                        // Event Bindings
                        // --------------------
                        $('#attribute_id').on('change', loadAttributeItems);

                        // When user selects attribute items (e.g., colors or sizes)
                        $(document).on('change', '.attribute-item', function() {
                            loadVariantCombinations();
                            updateImageUploadFields(); // 👈 Add this
                        });

                        // When SKU or Price changes, refresh variant combinations
                        $(document).on('keyup change', '#sku_prefix,#price,#purchase_price', loadVariantCombinations);

                        // Remove variant row
                        $(document).on('click', '.remove-variant', function() {
                            $(this).closest('tr').remove();
                        });

                        // Initialize on page load
                        initChoices();
                    });
                    </script>

                @endpush

                


                
            </div>

            <!-- Right Column: Categories + Brands + Tags + Settings -->
            <div class="col-md-4">
                <!-- Product Categories -->
                <div class="card custom-card">
                    <div class="card-header justify-content-between">
                        <div class="card-title">Categories</div>
                        <a href="#" class="btn btn-primary-light btn-sm"><i class="bi bi-plus-lg"></i> Add New</a>
                    </div>
                    <div class="card-body pt-1">
                        <label for="category_id" class="form-label">Category <span class="text-danger">*</span></label>
                        <select name="category_id" id="category_id" class="form-select" required>
                            <option value="">Select Category</option>
                            @foreach($categories as $category)
                                <option value="{{ $category->id }}" {{ old('category_id')==$category->id ? 'selected' : '' }}>{{ $category->name }}</option>
                            @endforeach
                        </select>
                        @error('category_id') <div class="text-danger mt-1">{{ $message }}</div> @enderror
                    </div>
                </div>
                <!-- Product Brand -->
                <div class="card custom-card">
                    <div class="card-header justify-content-between">
                        <div class="card-title">Brands</div>
                        <a href="#" class="btn btn-primary-light btn-sm"><i class="bi bi-plus-lg"></i> Add New</a>
                    </div>
                    <div class="card-body pt-1">
                        <label for="brand_id" class="form-label">Brand</label>
                        <select name="brand_id" id="brand_id" class="form-select">
                            <option value="">Select Brand</option>
                            @foreach($brands as $brand)
                                <option value="{{ $brand->id }}" {{ old('brand_id')==$brand->id ? 'selected' : '' }}>{{ $brand->name }}</option>
                            @endforeach
                        </select>
                        @error('brand_id') <div class="text-danger mt-1">{{ $message }}</div> @enderror
                    </div>
                </div>
                <!-- Product Tag -->
                <div class="card custom-card">
                    <div class="card-header justify-content-between">
                        <div class="card-title">Tags</div>
                        <a href="#" class="btn btn-primary-light btn-sm"><i class="bi bi-plus-lg"></i> Add New</a>
                    </div>
                    <div class="card-body pt-1">
                        <label for="brand_id" class="form-label">Tag</label>
                        <select name="brand_id" id="brand_id" class="form-select">
                            <option value="">Select Tag</option>
                            @foreach($brands as $brand)
                                <option value="{{ $brand->id }}" {{ old('brand_id')==$brand->id ? 'selected' : '' }}>{{ $brand->name }}</option>
                            @endforeach
                        </select>
                        @error('brand_id') <div class="text-danger mt-1">{{ $message }}</div> @enderror
                    </div>
                </div>

                <!-- Settings -->
                <div class="card custom-card mt-3">
                    <div class="card-header">
                        <div class="card-title">Settings</div>
                    </div>
                    <div class="card-body">
                        <div class="mb-1">
                            <label for="product_type" class="form-label">Product Type</label>
                            <select class="form-select" id="product_type" name="product_type">
                                <option value="sale" {{ old('product_type',1)==1?'selected':'' }}>Sale</option>
                                <option value="hot" {{ old('product_type',1)==0?'selected':'' }}>Hot</option>
                                <option value="regular" {{ old('product_type',1)==0?'selected':'' }}>Regular</option>
                                <option value="trending" {{ old('product_type',1)==0?'selected':'' }}>Trending</option>
                            </select>
                        </div>
                        <div class="mb-1">
                            <label for="visibility" class="form-label">Visibility</label>
                            <select class="form-select" id="visibility" name="visibility">
                                <option value="public" {{ old('visibility',1)==1?'selected':'' }}>Public</option>
                                <option value="private" {{ old('visibility',1)==0?'selected':'' }}>Private</option>
                                <option value="schedule" {{ old('visibility',1)==0?'selected':'' }}>Schedule</option>
                            </select>
                        </div>
                        <div class="mb-1">
                            <label for="status" class="form-label">Status</label>
                            <select class="form-select" id="status" name="status">
                                <option value="1" {{ old('status',1)==1?'selected':'' }}>Active</option>
                                <option value="0" {{ old('status',1)==0?'selected':'' }}>Inactive</option>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Actions -->
                <div class="card custom-card mt-3">
                    <div class="card-body">
                        <button type="submit" class="btn btn-primary w-100">Save Product</button>
                        <a href="{{ route('products.index') }}" class="btn btn-secondary w-100 mt-2">Cancel</a>
                    </div>
                </div>

            </div>
        </div>
    </form>

    <!-- JS for variants -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const addVariantBtn = document.getElementById('add-variant');
            const variantsContainer = document.getElementById('variants-container');
            const variantTemplate = document.getElementById('variant-template').content;

            addVariantBtn.addEventListener('click', () => {
                const clone = variantTemplate.cloneNode(true);
                variantsContainer.appendChild(clone);
            });

            variantsContainer.addEventListener('click', (e) => {
                if (e.target.classList.contains('remove-variant') || e.target.closest('.remove-variant')) {
                    e.target.closest('.variant-item').remove();
                }
            });
        });
    </script>
</x-backend-layout>
