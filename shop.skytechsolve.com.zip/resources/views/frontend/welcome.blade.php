<x-frontend-layout title="Home Page" :breadcrumbs="$breadcrumbs" :seotags="$seotags">
    <h1 style="justify-content: center;display: flex;align-items: center;justify-items: center;flex-direction: column; height: 100vh;font-family: cursive;color: #02ff00;">
       <p> Hello, Welcome Master Teamplate!!! </p>
       <a href="{{route('login')}}">Login</a>
    </h1>
</x-frontend-layout>
