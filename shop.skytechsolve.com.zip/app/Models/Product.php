<?php
// app/Models/Product.php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Product extends Model
{
    use HasFactory;

    protected $fillable = [
        'name', 'slug', 'sku_prefix', 'description', 'specification',
        'category_id', 'brand_id', 'base_price', 'thumbnail', 'total_stock',
        'product_type', 'visibility', 'published_at', 'has_variant', 'status'
    ];

    protected $casts = [
        'specification' => 'array',
        'published_at' => 'datetime',
        'has_variant' => 'boolean',
        'status' => 'boolean',
        'base_price' => 'decimal:2',
        'total_stock' => 'integer',
        'views' => 'integer',
    ];

    // Relationships
    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    public function brand(): BelongsTo
    {
        return $this->belongsTo(Brand::class);
    }

    public function variants(): HasMany
    {
        return $this->hasMany(ProductVariant::class);
    }

    public function discounts(): HasMany
    {
        return $this->hasMany(ProductDiscount::class);
    }

    public function shipping(): HasOne
    {
        return $this->hasOne(ProductShipping::class);
    }

    public function attributes()
    {
        return $this->hasManyThrough(Attribute::class, ProductVariantItem::class, 'product_variant_id', 'id', 'id', 'attribute_id');
    }

    // Scopes
    public function scopeActive($query)
    {
        return $query->where('status', true);
    }

    public function scopeVisible($query)
    {
        return $query->where('visibility', 'public')
                    ->where('published_at', '<=', now());
    }

    public function scopeWithVariant($query)
    {
        return $query->where('has_variant', true);
    }

    // Accessors & Mutators
    public function getThumbnailUrlAttribute()
    {
        return $this->thumbnail ? asset('storage/' . $this->thumbnail) : asset('images/default-product.png');
    }

    public function getIsPublishedAttribute()
    {
        return $this->published_at && $this->published_at <= now();
    }

    public function getCurrentDiscountAttribute()
    {
        return $this->discounts()
            ->where('status', true)
            ->where('start_date', '<=', now())
            ->where('end_date', '>=', now())
            ->first();
    }
}
