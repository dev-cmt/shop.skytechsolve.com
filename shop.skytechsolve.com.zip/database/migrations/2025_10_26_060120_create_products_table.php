<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('slug')->unique();
            $table->string('sku_prefix')->default('PROD');
            $table->text('description')->nullable();
            $table->json('specification')->nullable();
            $table->foreignId('category_id')->constrained()->onDelete('cascade');
            $table->foreignId('brand_id')->nullable()->constrained()->onDelete('set null');
            $table->decimal('base_price', 10, 2)->default(0.00);
            $table->decimal('purchase_price', 10, 2)->default(0.00);
            $table->string('thumbnail')->nullable();
            $table->integer('total_stock')->default(0);
            $table->enum('product_type', ['sale', 'hot', 'regular', 'trending'])->default('regular');
            $table->enum('visibility', ['public', 'private', 'schedule'])->default('public');
            $table->timestamp('published_at')->nullable();
            $table->unsignedBigInteger('views')->default(0);
            $table->boolean('has_variant')->default(false);
            $table->boolean('status')->default(true);
            $table->timestamps();

            $table->index(['category_id', 'status']);
            $table->index(['product_type', 'status']);
            $table->index(['visibility', 'published_at']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
