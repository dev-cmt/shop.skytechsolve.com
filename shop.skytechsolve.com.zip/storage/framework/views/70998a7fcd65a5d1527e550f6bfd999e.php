
<?php if (isset($component)) { $__componentOriginala2edde5e1c82a5de5f92a34d70a8fe30 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala2edde5e1c82a5de5f92a34d70a8fe30 = $attributes; } ?>
<?php $component = App\View\Components\BackendLayout::resolve(['title' => 'Role & Permissions List'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\BackendLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('css'); ?>
        <style>
            .custom-tr td {
                    vertical-align: text-top !important;
                }
        </style>
        <!-- Sweetalerts CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('backEnd/assets/libs/sweetalert2/sweetalert2.min.css')); ?>">
    <?php $__env->stopPush(); ?>

    <div class="mt-4"></div>
    <div class="card custom-card">
        <div class="card-header justify-content-between">
            <div class="card-title">
                Create Role & Permissions
            </div>
            <div class="prism-toggle">
                <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-sm btn-success-gradient">Add Role</a>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table id="mytable" class="table table-bordered text-nowrap" style="width:100%">
                    <thead>
                        <tr>
                            <th>SL</th>
                            <th>Name</th>
                            <th>Permissions</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php ($i = 1); ?>
                        <?php if(count($roles) > 0): ?>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $rolePermissions = DB::table('role_has_permissions')
                                    ->where('role_has_permissions.role_id', $item->id)
                                    ->pluck('role_has_permissions.permission_id', 'role_has_permissions.permission_id')
                                    ->all();
                                ?>
                                <tr class="custom-tr">
                                    <td style="width: 1%"><?php echo e($i++); ?></td>
                                    <td>
                                        <?php echo e($item->name); ?>

                                    </td>
                                    <td style="text-wrap: wrap;">
                                        <?php $__currentLoopData = $item->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <span
                                                    class="badge bg-success-transparent"><?php echo e(ucwords(str_replace('-', ' ',$permission->name))); ?>

                                                </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>


                                    <td width="5%">
                                        <a href="<?php echo e(route('roles.edit', $item->id)); ?>" title="Edit"
                                            class="badge bg-outline-info mb-1 w-100 edit-btn">Edit
                                        </a>
                                        <br>

                                        <a href="javascript:void(0);" onclick="deleteForm(<?php echo e($item->id); ?>)"
                                            title="Delete" class="badge bg-outline-danger btn_delete mb-1 w-100">Delete</a>
                                    </td>


                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" class="text-danger text-center">No Data Available!</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
        </div>
    </div>
    
    <?php $__env->startPush('js'); ?>
        <!-- Sweetalerts JS -->
        <script src="<?php echo e(asset('backEnd/assets/libs/sweetalert2/sweetalert2.min.js')); ?>"></script>
    <?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala2edde5e1c82a5de5f92a34d70a8fe30)): ?>
<?php $attributes = $__attributesOriginala2edde5e1c82a5de5f92a34d70a8fe30; ?>
<?php unset($__attributesOriginala2edde5e1c82a5de5f92a34d70a8fe30); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala2edde5e1c82a5de5f92a34d70a8fe30)): ?>
<?php $component = $__componentOriginala2edde5e1c82a5de5f92a34d70a8fe30; ?>
<?php unset($__componentOriginala2edde5e1c82a5de5f92a34d70a8fe30); ?>
<?php endif; ?><?php /**PATH D:\xampp8\htdocs\shop.skytechsolve.com\resources\views/backend/roles/index.blade.php ENDPATH**/ ?>