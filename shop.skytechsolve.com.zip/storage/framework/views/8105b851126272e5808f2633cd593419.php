<aside class="app-sidebar sticky" id="sidebar">
    <!-- Start::main-sidebar-header -->
    <div class="main-sidebar-header">
        
        <a href="<?php echo e(route('dashboard')); ?>" class="header-logo">
            <img src="<?php echo e(asset($settings ? $settings->logo : '')); ?>" alt="logo">
        </a>
    </div>
    <!-- End::main-sidebar-header -->

    <!-- Start::main-sidebar -->
    <div class="main-sidebar" id="sidebar-scroll">

        <!-- Start::nav -->
        <nav class="main-menu-container nav nav-pills flex-column sub-open">
            <div class="slide-left" id="slide-left">
                <svg xmlns="http://www.w3.org/2000/svg" fill="#7b8191" width="24" height="24" viewBox="0 0 24 24"> <path d="M13.293 6.293 7.586 12l5.707 5.707 1.414-1.414L10.414 12l4.293-4.293z"></path> </svg>
            </div>

            <ul class="main-menu">

                <!-- Dashboard - Always visible -->
                <li class="slide">
                    <a href="<?php echo e(route('dashboard')); ?>"
                        class="side-menu__item <?php echo e(Request::is('dashboard') ? 'active' : ''); ?>">
                        <i class="bx bxs-dashboard side-menu__icon"></i>
                        <span class="side-menu__label">Dashboard</span>
                    </a>
                </li>

                <!-- Proudct -->
                <li class="slide has-sub <?php echo e(Request::is('products*') || Request::is('categories*') || Request::is('brands*') || Request::is('tags*') || Request::is('attributes*') ? 'active open' : ''); ?>">
                    <a href="javascript:void(0);" class="side-menu__item <?php echo e(Request::is('products*') || Request::is('categories*') || Request::is('brands*') || Request::is('tags*') || Request::is('attributes*') ? 'active' : ''); ?>">
                        <i class="bx bxs-package side-menu__icon"></i>
                        <span class="side-menu__label">Products</span>
                        <i class="fe fe-chevron-right side-menu__angle"></i>
                    </a>
                    <ul class="slide-menu child1">
                        <li class="slide">
                            <a href="<?php echo e(route('products.index')); ?>" class="side-menu__item <?php echo e(Request::is('products*') ? 'active' : ''); ?>">
                                Product List
                            </a>
                        </li>
                        <li class="slide">
                            <a href="<?php echo e(route('categories.index')); ?>" class="side-menu__item <?php echo e(Request::is('categories*') ? 'active' : ''); ?>">
                                Category List
                            </a>
                        </li>
                        <li class="slide">
                            <a href="<?php echo e(route('brands.index')); ?>" class="side-menu__item <?php echo e(Request::is('brands*') ? 'active' : ''); ?>">
                                Brand List
                            </a>
                        </li>
                        <li class="slide">
                            <a href="<?php echo e(route('tags.index')); ?>" class="side-menu__item <?php echo e(Request::is('tags*') ? 'active' : ''); ?>">
                                Tag List
                            </a>
                        </li>
                        <li class="slide">
                            <a href="<?php echo e(route('attributes.index')); ?>" class="side-menu__item <?php echo e(Request::is('attributes*') ? 'active' : ''); ?>">
                                Attributes
                            </a>
                        </li>
                    </ul>
                </li>



                <!-- Developer API -->
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view developer api')): ?>
                <li class="slide">
                    <a href="<?php echo e(route('developer-api.index')); ?>"
                        class="side-menu__item <?php echo e(Request::is('developer-api*') ? 'active' : ''); ?>">
                        <i class="bx bx-code-alt side-menu__icon"></i>
                        <span class="side-menu__label">Developer Api</span>
                    </a>
                </li>
                <?php endif; ?>


                <!-- SEO Settings -->
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view seo')): ?>
                <li class="slide">
                    <a href="<?php echo e(route('settings.seo.index')); ?>" class="side-menu__item <?php echo e(Request::is('seo-pages*') ? 'active' : ''); ?>">
                        <i class="bx bx-search-alt-2 side-menu__icon"></i>
                        <span class="side-menu__label">SEO Settings</span>
                    </a>
                </li>
                <?php endif; ?>


                <!-- Authentication - Only for admin -->
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view roles', 'view users'])): ?>
                <li class="slide has-sub <?php echo e(Request::is('roles*') || Request::is('users*') ? 'active open' : ''); ?>">
                    <a href="javascript:void(0);" class="side-menu__item <?php echo e(Request::is('roles*') || Request::is('users*') ? 'active' : ''); ?>">
                        <i class="bx bx-fingerprint side-menu__icon"></i>
                        <span class="side-menu__label">Authentication</span>
                        <i class="fe fe-chevron-right side-menu__angle"></i>
                    </a>
                    <ul class="slide-menu child1">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view roles')): ?>
                        <li class="slide">
                            <a href="<?php echo e(route('roles.index')); ?>" class="side-menu__item <?php echo e(Request::is('roles*') ? 'active' : ''); ?>">
                                Role & Permission
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view users')): ?>
                        <li class="slide">
                            <a href="<?php echo e(route('users.index')); ?>" class="side-menu__item <?php echo e(Request::is('users*') ? 'active' : ''); ?>">
                                Users Manage
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>


                <!-- Settings -->
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view settings')): ?>
                <li class="slide">
                    <a href="<?php echo e(route('setting.index')); ?>" class="side-menu__item <?php echo e(Request::is('setting*') ? 'active' : ''); ?>">
                        <i class="bx bxs-cog side-menu__icon"></i>
                        <span class="side-menu__label">Web Settings</span>
                    </a>
                </li>
                <?php endif; ?>

            </ul>
            <div class="slide-right" id="slide-right">
                <svg xmlns="http://www.w3.org/2000/svg" fill="#7b8191" width="24" height="24"
                    viewBox="0 0 24 24">
                    <path d="M10.707 17.707 16.414 12l-5.707-5.707-1.414 1.414L13.586 12l-4.293 4.293z"></path>
                </svg>
            </div>
        </nav>
        <!-- End::nav -->

    </div>
    <!-- End::main-sidebar -->

</aside>
<?php /**PATH D:\xampp8\htdocs\shop.skytechsolve.com\resources\views/backend/partials/sidebar.blade.php ENDPATH**/ ?>