<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e($title ?? config('app.name', 'Laravel')); ?></title>

    <!-- Favicon -->
    <link rel="icon" href="<?php echo e(asset($settings ? $settings->favicon : '')); ?>" type="image/x-icon">

    <!-- Main Theme Js -->
    <script src="<?php echo e(asset('backend/js/authentication-main.js')); ?>"></script>
    
    <!-- Bootstrap Css -->
    <link id="style" href="<?php echo e(asset('backend/libs/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Style Css -->
    <link href="<?php echo e(asset('backend/css/styles.min.css')); ?>" rel="stylesheet">

    <!-- Icons Css -->
    <link href="<?php echo e(asset('backend/css/icons.min.css')); ?>" rel="stylesheet" >

    <?php echo $__env->yieldPushContent('css'); ?>
</head>
<body>

    <div class="container">
        <?php echo e($slot); ?>

    </div>

    <!-- Jquery JS -->
    <script src="<?php echo e(asset('backend/js/jquery.js')); ?>"></script>

    <!-- Custom-Switcher JS -->
    <script src="<?php echo e(asset('backend/js/custom-switcher.min.js')); ?>"></script>

    <!-- Bootstrap JS -->
    <script src="<?php echo e(asset('backend/js/bootstrap.bundle.min.js')); ?>"></script>

    <!-- Show Password JS -->
    <script src="<?php echo e(asset('backend/js/show-password.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('js'); ?>
</body>
</html>
<?php /**PATH D:\xampp8\htdocs\shop.skytechsolve.com\resources\views/auth/layouts/master.blade.php ENDPATH**/ ?>