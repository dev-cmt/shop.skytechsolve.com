<?php if (isset($component)) { $__componentOriginala6488acc797ee40bc55ed6344dee8ea1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala6488acc797ee40bc55ed6344dee8ea1 = $attributes; } ?>
<?php $component = App\View\Components\AuthLayout::resolve(['title' => 'Forgot Password'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AuthLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="row justify-content-center align-items-center authentication authentication-basic h-100">
        <div class="col-xxl-4 col-xl-5 col-lg-5 col-md-6 col-sm-8 col-12">
            <div class="mt-4 mb-3 d-flex justify-content-center">
                <a href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo e(asset($settings ? $settings->logo : '')); ?>" style="height: 75px" alt="logo" class="desktop-logo">
                    <img src="<?php echo e(asset($settings ? $settings->logo : '')); ?>" style="height: 75px" alt="logo" class="desktop-dark">
                </a>
            </div>

            <div class="card custom-card">
                <div class="card-body p-5">
                    <p class="h5 fw-semibold mb-2 text-center">Forgot Password</p>
                    <p class="mb-4 text-muted op-7 fw-normal text-center">Enter your email address and we'll send you a link to reset your password.</p>

                    <?php if(session('status')): ?>
                        <div class="alert alert-success"><?php echo e(session('status')); ?></div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('password.email')); ?>" id="forgot-password-form">
                        <?php echo csrf_field(); ?>
                        <div class="row gy-3">
                            <div class="col-xl-12">
                                <label for="email" class="form-label text-default">Email</label>
                                <input type="email" class="form-control form-control-lg <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email" placeholder="Enter your email" value="<?php echo e(old('email')); ?>" required autofocus>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger small"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-xl-12 d-grid mt-2">
                                <button type="submit" class="btn btn-lg btn-primary" id="submit-btn">Send Password Reset Link</button>
                            </div>

                            <div class="col-xl-12 text-center mt-3">
                                <a href="<?php echo e(route('login')); ?>" class="text-primary">Back to Sign In</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('js'); ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        function startCountdown(duration) {
            let $btn = $('#submit-btn'),
                originalText = $btn.text(),
                timer = duration;

            $btn.prop('disabled', true).text(`${originalText} (${timer}s)`);

            let countdown = setInterval(function() {
                timer--;
                $btn.text(`${originalText} (${timer}s)`);

                if(timer <= 0) {
                    clearInterval(countdown);
                    $btn.prop('disabled', false).text(originalText);
                }
            }, 1000);
        }

        $(function(){
            const countdownTime = 120; // 2 minutes

            // Start countdown if session status exists (after page reload)
            <?php if(session('status')): ?>
                startCountdown(countdownTime);
            <?php endif; ?>

            // Start countdown on form submit
            $('#forgot-password-form').on('submit', function(){
                startCountdown(countdownTime);
            });
        });
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala6488acc797ee40bc55ed6344dee8ea1)): ?>
<?php $attributes = $__attributesOriginala6488acc797ee40bc55ed6344dee8ea1; ?>
<?php unset($__attributesOriginala6488acc797ee40bc55ed6344dee8ea1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala6488acc797ee40bc55ed6344dee8ea1)): ?>
<?php $component = $__componentOriginala6488acc797ee40bc55ed6344dee8ea1; ?>
<?php unset($__componentOriginala6488acc797ee40bc55ed6344dee8ea1); ?>
<?php endif; ?>
<?php /**PATH D:\xampp8\htdocs\shop.skytechsolve.com\resources\views/auth/forgot-password.blade.php ENDPATH**/ ?>