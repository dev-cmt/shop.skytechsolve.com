<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <!-- Meta Data -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    

    <?php echo $seotags ?? ''; ?>

	<?php echo $breadcrumbs ?? ''; ?>

	<?php echo $jsonld ?? ''; ?>


    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">


    <?php echo $__env->yieldPushContent('css'); ?>
</head>

<body class="<?php echo e(session('theme', 'light')); ?>">
    <!-- Navbar / Header -->
    <?php echo $__env->make('frontend.partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Main Page Content -->
    <main class="py-4">
        <?php echo e($slot); ?>

    </main>

    <!-- Footer -->
    <?php echo $__env->make('frontend.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->yieldPushContent('js'); ?>
</body>
</html>
<?php /**PATH D:\xampp8\htdocs\shop.skytechsolve.com\resources\views/frontend/layouts/master.blade.php ENDPATH**/ ?>