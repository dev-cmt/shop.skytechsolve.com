<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" dir="ltr" data-nav-layout="vertical" data-theme-mode="light" data-header-styles="light" data-menu-styles="dark" data-toggled="close">
<head>
    <!-- Meta Data -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e($title ? $title . ' | ' : ''); ?><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Favicon -->
    <link rel="icon" href="<?php echo e(asset($settings ? $settings->favicon : '')); ?>" type="image/x-icon">
    <!-- Choices JS -->
    <script src="<?php echo e(asset('backend')); ?>/libs/choices.js/public/assets/scripts/choices.min.js"></script>
    <!-- Main Theme Js -->
    <script src="<?php echo e(asset('backend')); ?>/js/main.js"></script>
    <!-- Bootstrap Css -->
    <link id="style" href="<?php echo e(asset('backend')); ?>/libs/bootstrap/css/bootstrap.min.css" rel="stylesheet" >
    <!-- Style Css -->
    <link href="<?php echo e(asset('backend')); ?>/css/styles.min.css" rel="stylesheet" >
    <!-- Icons Css -->
    <link href="<?php echo e(asset('backend')); ?>/css/icons.css" rel="stylesheet" >
    <!-- Node Waves Css -->
    <link href="<?php echo e(asset('backend')); ?>/libs/node-waves/waves.min.css" rel="stylesheet" >
    <!-- Simplebar Css -->
    <link href="<?php echo e(asset('backend')); ?>/libs/simplebar/simplebar.min.css" rel="stylesheet" >
    <!-- Color Picker Css -->
    <link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/libs/flatpickr/flatpickr.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/libs/@simonwep/pickr/themes/nano.min.css">
    <!-- Choices Css -->
    <link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/libs/choices.js/public/assets/styles/choices.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/libs/jsvectormap/css/jsvectormap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/libs/swiper/swiper-bundle.min.css">
    <!-- Sweetalert-2 Css -->
    <link rel="stylesheet" href="<?php echo e(asset('backend/libs/sweetalert2/sweetalert2.min.css')); ?>">

    <?php echo $__env->yieldPushContent('css'); ?>
</head>
<body>

    <?php echo $__env->make('backend.partials.theme', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="page">
        <!-- app-header -->
        <?php echo $__env->make('backend.partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- /app-header -->
        <!-- Start::app-sidebar -->
        <?php echo $__env->make('backend.partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- End::app-sidebar -->

        <!-- Start::app-content -->
        <div class="main-content app-content">
            <div class="container-fluid">

                <?php echo e($slot); ?>


            </div>
        </div>
        <!-- End::app-content -->

        <!-- Footer Start -->
        <?php echo $__env->make('backend.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- Footer End -->

    </div>


    <!-- Scroll To Top -->
    <div class="scrollToTop">
        <span class="arrow"><i class="ri-arrow-up-s-fill fs-20"></i></span>
    </div>
    <div id="responsive-overlay"></div>
    <!-- Scroll To Top -->

    <!-- Popper JS -->
    <script src="<?php echo e(asset('backend')); ?>/libs/@popperjs/core/umd/popper.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="<?php echo e(asset('backend')); ?>/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Defaultmenu JS -->
    <script src="<?php echo e(asset('backend')); ?>/js/defaultmenu.min.js"></script>
    <!-- Node Waves JS-->
    <script src="<?php echo e(asset('backend')); ?>/libs/node-waves/waves.min.js"></script>
    <!-- Sticky JS -->
    <script src="<?php echo e(asset('backend')); ?>/js/sticky.js"></script>
    <!-- Simplebar JS -->
    <script src="<?php echo e(asset('backend')); ?>/libs/simplebar/simplebar.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/js/simplebar.js"></script>
    <!-- Color Picker JS -->
    <script src="<?php echo e(asset('backend')); ?>/libs/@simonwep/pickr/pickr.es5.min.js"></script>
    <!-- JSVector Maps JS -->
    <script src="<?php echo e(asset('backend')); ?>/libs/jsvectormap/js/jsvectormap.min.js"></script>
    <!-- JSVector Maps MapsJS -->
    <script src="<?php echo e(asset('backend')); ?>/libs/jsvectormap/maps/world-merc.js"></script>
    <!-- Apex Charts JS -->
    <script src="<?php echo e(asset('backend')); ?>/libs/apexcharts/apexcharts.min.js"></script>
    <!-- Chartjs Chart JS -->
    <script src="<?php echo e(asset('backend')); ?>/libs/chart.js/chart.min.js"></script>
    <!-- CRM-Dashboard -->
    <script src="<?php echo e(asset('backend')); ?>/js/crm-dashboard.js"></script>
    <!-- Custom-Switcher JS -->
    <script src="<?php echo e(asset('backend')); ?>/js/custom-switcher.min.js"></script>
    <!-- Custom JS -->
    <script src="<?php echo e(asset('backend')); ?>/js/custom.js"></script>


    <!-- Jquer JS -->
    <script src="<?php echo e(asset('backend/js/jquery.js')); ?>"></script>
    <!-- Sweetalert-2 JS -->
    <script src="<?php echo e(asset('backend')); ?>/libs/sweetalert2/sweetalert2.min.js"></script>

    <script>
        <?php if(session()->has('success')): ?>
            Swal.fire({
                position: 'center',
                icon: 'success',
                title: '<?php echo e(session('success')); ?>',
                showConfirmButton: false,
                timer: 1500
            });
        <?php endif; ?>
    </script>

    <?php echo $__env->yieldPushContent('js'); ?>

</body>
</html>
<?php /**PATH D:\xampp8\htdocs\shop.skytechsolve.com\resources\views/backend/layouts/master.blade.php ENDPATH**/ ?>