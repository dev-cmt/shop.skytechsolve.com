<?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-4 mb-2 attribute-item-wrapper">
    <label class="form-label"><?php echo e($attribute->name); ?> Items</label>
    <select class="form-select attribute-item"
            data-id="<?php echo e($attribute->id); ?>"
            data-name="<?php echo e($attribute->name); ?>"
            data-has-image="<?php echo e($attribute->has_image ? 1 : 0); ?>"
            multiple
            name="attribute_items[<?php echo e($attribute->id); ?>][]">
        <?php $__currentLoopData = $attribute->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <?php if($attribute->has_image): ?>
    <div class="image-upload-container" data-attr-id="<?php echo e($attribute->id); ?>">
        <label class="form-label fw-semibold">Upload Images for <?php echo e($attribute->name); ?></label>
        <div class="image-upload-fields border rounded p-2 bg-light"></div>
    </div>
    <?php endif; ?>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\xampp8\htdocs\shop.skytechsolve.com\resources\views/backend/products/partials/_attribute_items.blade.php ENDPATH**/ ?>