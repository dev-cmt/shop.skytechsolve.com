<?php if (isset($component)) { $__componentOriginala2edde5e1c82a5de5f92a34d70a8fe30 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala2edde5e1c82a5de5f92a34d70a8fe30 = $attributes; } ?>
<?php $component = App\View\Components\BackendLayout::resolve(['title' => 'Attributes Management'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\BackendLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<!-- Page Header -->
<div class="d-md-flex d-block align-items-center justify-content-between my-4 page-header-breadcrumb">
    <h1 class="page-title fw-semibold fs-18 mb-0">Attributes Management</h1>
    <div class="ms-md-1 ms-0">
        <nav>
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Attributes</li>
            </ol>
        </nav>
    </div>
</div>

<div class="row">
    <div class="col-xl-12">
        <div class="card custom-card">
            <div class="card-header justify-content-between d-flex align-items-center">
                <div class="card-title">Attributes List</div>
                <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#createAttributeModal">
                    <i class="ri-add-line me-1 fw-semibold align-middle"></i> Add Attribute
                </button>
            </div>
            <div class="card-body">

                <div id="alertMsg"></div>

                <div class="table-responsive">
                    <table class="table text-nowrap table-hover border table-bordered">
                        <thead>
                            <tr>
                                <th>SL</th>
                                <th>Name</th>
                                <th>Display Type</th>
                                <th>Has Image</th>
                                <th>Items</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="attributesTable">
                            <?php $__empty_1 = true; $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr id="attr-<?php echo e($attr->id); ?>">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($attr->name); ?></td>
                                <td><span class="badge bg-info text-dark"><?php echo e(ucfirst($attr->display_type)); ?></span></td>
                                <td>
                                    <?php if($attr->has_image): ?>
                                        <span class="badge bg-success">Yes</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">No</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <ul id="items-<?php echo e($attr->id); ?>" class="list-unstyled mb-0">
                                        <?php $__currentLoopData = $attr->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li id="item-<?php echo e($item->id); ?>" class="d-flex justify-content-between align-items-center mb-1">
                                            <?php echo e($item->name); ?>

                                            <div class="btn-group btn-group-sm">
                                                <button class="btn btn-icon btn-wave waves-effect waves-light btn-sm btn-primary-light editItemBtn"
                                                    data-id="<?php echo e($item->id); ?>"
                                                    data-name="<?php echo e($item->name); ?>"
                                                    data-value="<?php echo e($item->value); ?>"
                                                    data-sort="<?php echo e($item->sort_order); ?>"
                                                    data-attribute="<?php echo e($attr->id); ?>">
                                                    <i class="ri-edit-line"></i>
                                                </button>
                                                <button class="btn btn-icon btn-wave waves-effect waves-light btn-sm btn-danger-light deleteItem" data-id="<?php echo e($item->id); ?>">
                                                    <i class="ri-delete-bin-line"></i>
                                                </button>
                                            </div>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                    <button class="btn btn-sm btn-outline-success mt-1 addItemBtn" data-attribute="<?php echo e($attr->id); ?>">
                                        <i class="ri-add-line"></i> Add Item
                                    </button>
                                </td>
                                <td class="text-center">
                                    <div class="btn-list">
                                        <button type="button" class="btn btn-sm btn-warning-light editAttrBtn"
                                            data-id="<?php echo e($attr->id); ?>"
                                            data-name="<?php echo e($attr->name); ?>"
                                            data-display="<?php echo e($attr->display_type); ?>"
                                            data-image="<?php echo e($attr->has_image); ?>"
                                            data-bs-toggle="modal"
                                            data-bs-target="#createAttributeModal">
                                            <i class="ri-pencil-line"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-danger-light deleteAttrBtn" data-id="<?php echo e($attr->id); ?>">
                                            <i class="ri-delete-bin-line"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted">No attributes found.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
</div>

<!-- Attribute Modal -->
<div class="modal fade" id="createAttributeModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form id="attributeForm" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" id="attr_id">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h6 class="modal-title">Add / Edit Attribute</h6>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Name</label>
                        <input type="text" name="name" id="attr_name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Display Type</label>
                        <select name="display_type" id="attr_display" class="form-select" required>
                            <option value="text">Text</option>
                            <option value="color">Color</option>
                            <option value="image">Image</option>
                            <option value="dropdown">Dropdown</option>
                        </select>
                    </div>
                    <div class="form-check form-switch">
                        <input type="checkbox" class="form-check-input" id="attr_image" name="has_image" value="1">
                        <label class="form-check-label" for="attr_image">Has Image</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Close</button>
                    <button class="btn btn-primary" id="saveAttrBtn" type="submit">Save Attribute</button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Add/Edit Item Modal -->
<div class="modal fade" id="addItemModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form id="itemForm" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" id="item_id">
            <input type="hidden" name="attribute_id" id="item_attr_id">
            <div class="modal-content">
                <div class="modal-header bg-success text-white">
                    <h6 class="modal-title">Add / Edit Item</h6>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Name</label>
                        <input type="text" name="name" id="item_name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Value</label>
                        <input type="text" name="value" id="item_value" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Sort Order</label>
                        <input type="number" name="sort_order" id="item_sort" class="form-control" value="0">
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Close</button>
                    <button class="btn btn-success" type="submit">Save Item</button>
                </div>
            </div>
        </form>
    </div>
</div>

<?php $__env->startPush('js'); ?>
<script>
$(document).ready(function() {

    // ===== Attribute Modal =====
    $('#createAttributeModal').on('show.bs.modal', function(event){
        let button = $(event.relatedTarget);
        let form = $(this).find('form')[0];
        form.reset();
        $('#attr_id').val('');
        $(this).find('form').attr('action', "<?php echo e(route('attributes.store')); ?>");

        if(button.hasClass('editAttrBtn')){
            $('#attr_id').val(button.data('id'));
            $('#attr_name').val(button.data('name'));
            $('#attr_display').val(button.data('display'));
            $('#attr_image').prop('checked', button.data('image') == 1);
            $(this).find('form').attr('action', "<?php echo e(route('attributes.update')); ?>");
        }
    });

    $('#attributeForm').on('submit', function(e){
        e.preventDefault();
        $.post($(this).attr('action'), $(this).serialize(), function(res){
            if(res.success) location.reload();
        });
    });

    // ===== Attribute Item Modal =====
    $(document).on('click', '.addItemBtn', function(){
        $('#itemForm')[0].reset();
        $('#item_id').val('');
        $('#item_attr_id').val($(this).data('attribute'));
        $('#addItemModal').modal('show');
        $('#itemForm').attr('action', "<?php echo e(route('attribute-items.store')); ?>");
    });

    $(document).on('click', '.editItemBtn', function(){
        $('#itemForm')[0].reset();
        let btn = $(this);
        $('#item_id').val(btn.data('id'));
        $('#item_name').val(btn.data('name'));
        $('#item_value').val(btn.data('value'));
        $('#item_sort').val(btn.data('sort'));
        $('#item_attr_id').val(btn.data('attribute'));
        $('#addItemModal').modal('show');
        $('#itemForm').attr('action', "<?php echo e(route('attribute-items.update')); ?>");
    });

    $('#itemForm').on('submit', function(e){
        e.preventDefault();
        $.post($(this).attr('action'), $(this).serialize(), function(res){
            if(res.success) location.reload();
        });
    });

    // ===== Delete Attribute =====
    $(document).on('click', '.deleteAttrBtn', function(){
        if(!confirm('Delete this attribute?')) return;
        let id = $(this).data('id');
        $.post("<?php echo e(route('attributes.destroy')); ?>", {id:id, _token:"<?php echo e(csrf_token()); ?>"}, function(res){
            if(res.success) $('#attr-'+id).remove();
        });
    });

    // ===== Delete Item =====
    $(document).on('click', '.deleteItem', function(){
        if(!confirm('Delete this item?')) return;
        let id = $(this).data('id');
        $.post("<?php echo e(route('attribute-items.destroy')); ?>", {id:id, _token:"<?php echo e(csrf_token()); ?>"}, function(res){
            if(res.success) $('#item-'+id).remove();
        });
    });

});
</script>
<?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala2edde5e1c82a5de5f92a34d70a8fe30)): ?>
<?php $attributes = $__attributesOriginala2edde5e1c82a5de5f92a34d70a8fe30; ?>
<?php unset($__attributesOriginala2edde5e1c82a5de5f92a34d70a8fe30); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala2edde5e1c82a5de5f92a34d70a8fe30)): ?>
<?php $component = $__componentOriginala2edde5e1c82a5de5f92a34d70a8fe30; ?>
<?php unset($__componentOriginala2edde5e1c82a5de5f92a34d70a8fe30); ?>
<?php endif; ?>
<?php /**PATH D:\xampp8\htdocs\shop.skytechsolve.com\resources\views/backend/attributes/index.blade.php ENDPATH**/ ?>