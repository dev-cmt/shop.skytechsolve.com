<?php if(count($variants)): ?>
<table class="table table-sm table-bordered">
    <thead>
        <tr>
            <th>Variant Name</th>
            <th>SKU</th>
            <th>Price</th>
            <th>Purchase Price</th>
            <th>Quantity</th>
            <th class="text-center">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($variant['name']); ?></td>
            <td><input type="text" name="variants[sku][]" class="form-control form-control-sm" value="<?php echo e($variant['sku']); ?>"></td>
            <td><input type="number" name="variants[price][]" class="form-control form-control-sm" value="<?php echo e($variant['price']); ?>"></td>
            <td><input type="number" name="variants[purchase_price][]" class="form-control form-control-sm" value="<?php echo e($variant['purchase_price']); ?>"></td>
            <td><input type="number" name="variants[quantity][]" class="form-control form-control-sm" value="<?php echo e($variant['quantity']); ?>"></td>
            <td class="text-center">
                <button type="button" class="btn btn-sm btn-outline-danger remove-variant">X</button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php endif; ?>
<?php /**PATH D:\xampp8\htdocs\shop.skytechsolve.com\resources\views/backend/products/partials/_variant_table.blade.php ENDPATH**/ ?>