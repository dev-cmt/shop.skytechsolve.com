<?php if (isset($component)) { $__componentOriginala2edde5e1c82a5de5f92a34d70a8fe30 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala2edde5e1c82a5de5f92a34d70a8fe30 = $attributes; } ?>
<?php $component = App\View\Components\BackendLayout::resolve(['title' => 'Tags Management'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\BackendLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Page Header -->
    <div class="d-md-flex d-block align-items-center justify-content-between my-4 page-header-breadcrumb">
        <h1 class="page-title fw-semibold fs-18 mb-0">Add New Product</h1>
        <div class="ms-md-1 ms-0">
            <nav>
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('products.index')); ?>">Products</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Add New</li>
                </ol>
            </nav>
        </div>
    </div>

    <form action="<?php echo e(route('products.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row">
            <!-- Left Column: Basic Info + SEO + Discounts -->
            <div class="col-md-8">

                <!-- Basic Information -->
                <div class="card custom-card">
                    <div class="card-header">
                        <div class="card-title">Basic Information</div>
                    </div>
                    <div class="card-body">
                        <div class="mb-2">
                            <label for="name" class="form-label">Product Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name')); ?>" required>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-2">
                            <label for="description" class="form-label">Description</label>
                            <textarea name="description" id="description" class="form-control summernote" rows="4"><?php echo old('description'); ?></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <!-- Others Information -->
                <div class="card custom-card">
                    <div class="card-header">
                        <div class="card-title">
                            Others Information
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-xl-2">
                                <nav class="nav nav-tabs flex-column nav-style-4" role="tablist">
                                    <a class="nav-link active" data-bs-toggle="tab" role="tab" aria-current="page" href="#home-vertical-link" aria-selected="false">
                                        <i class="ri-home-smile-line me-2 align-middle d-inline-block"></i> Inventory
                                    </a>
                                    <a class="nav-link" data-bs-toggle="tab" role="tab" aria-current="page" href="#services-vertical-link" aria-selected="true">
                                        <i class="ri-coupon-line me-2 align-middle d-inline-block"></i> Discounts
                                    </a>
                                    <a class="nav-link" data-bs-toggle="tab" role="tab" aria-current="page" href="#about-vertical-link" aria-selected="false">
                                        <i class="ri-ship-line me-2 align-middle d-inline-block"></i> Shipping
                                    </a>
                                    <a class="nav-link" data-bs-toggle="tab" role="tab" aria-current="page" href="#contacts-vertical-link" aria-selected="false">
                                        <i class="ri-search-eye-line me-2 align-middle d-inline-block"></i> SEO Info.
                                    </a>
                                </nav>
                            </div>
                            <div class="col-xl-10">
                                <div class="tab-content">
                                    <div class="tab-pane show active text-muted" id="home-vertical-link" role="tabpanel">
                                        <div class="row">
                                            <div class="col-md-6 mb-1">
                                                <label class="form-label">SKU Prefix <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control form-control-sm" id="sku_prefix" name="sku_prefix" value="<?php echo e(old('sku_prefix','PROD')); ?>">
                                                <?php $__errorArgs = ['total_stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-md-6 mb-1">
                                                <label class="form-label">Base Price <span class="text-danger">*</span></label>
                                                <input type="number" class="form-control form-control-sm" id="price" name="price" value="<?php echo e(old('price','0.00')); ?>" min="0" step="0.01">
                                                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-md-6 mb-1">
                                                <label for="purchase_price" class="form-label">Purchase Price</label>
                                                <input type="number" class="form-control form-control-sm" id="purchase_price" name="purchase_price" value="<?php echo e(old('purchase_price')); ?>" required>
                                                <?php $__errorArgs = ['purchase_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-md-6 mb-1">
                                                <label for="base_price" class="form-label">Stock Management <span class="text-danger">*</span></label>
                                                <select name="discount_type" id="discount_type" class="form-select">
                                                    <option value="7 Day" <?php echo e(old('discount_type')=='percentage'?'selected':''); ?>>Quantity</option>
                                                    <option value="flat" <?php echo e(old('discount_type')=='flat'?'selected':''); ?>>In Stock</option>
                                                    <option value="flat" <?php echo e(old('discount_type')=='flat'?'selected':''); ?>>Out Of Stock</option>
                                                    <option value="flat" <?php echo e(old('discount_type')=='flat'?'selected':''); ?>>Upcomming</option>
                                                </select>
                                                <?php $__errorArgs = ['base_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-md-6 mb-1">
                                                <label for="total_stock" class="form-label">Total Stock</label>
                                                <input type="number" class="form-control form-control-sm" id="total_stock" name="total_stock" value="<?php echo e(old('total_stock', 0)); ?>">
                                                <?php $__errorArgs = ['total_stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-md-6 mb-1">
                                                <label for="stock_out" class="form-label">Stock Out <span class="text-danger">*</span></label>
                                                <input type="number" class="form-control form-control-sm" id="stock_out" name="stock_out" value="<?php echo e(old('stock_out', 1)); ?>" required>
                                                <?php $__errorArgs = ['base_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-md-6 mb-1">
                                                <label for="base_price" class="form-label">Alert Quantity</label>
                                                <input type="number" class="form-control form-control-sm" id="base_price" name="base_price" value="<?php echo e(old('base_price')); ?>" required>
                                                <?php $__errorArgs = ['base_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-md-6 mb-1">
                                                <label for="base_price" class="form-label">Expire</label>
                                                <select name="discount_type" id="discount_type" class="form-select">
                                                    <option value="">Select</option>
                                                    <option value="7 Day" <?php echo e(old('discount_type')=='percentage'?'selected':''); ?>>7 Days</option>
                                                    <option value="flat" <?php echo e(old('discount_type')=='flat'?'selected':''); ?>>15 Days</option>
                                                    <option value="flat" <?php echo e(old('discount_type')=='flat'?'selected':''); ?>>1 Month</option>
                                                    <option value="flat" <?php echo e(old('discount_type')=='flat'?'selected':''); ?>>2 Month</option>
                                                    <option value="flat" <?php echo e(old('discount_type')=='flat'?'selected':''); ?>>3 Month</option>
                                                    <option value="flat" <?php echo e(old('discount_type')=='flat'?'selected':''); ?>>6 Month</option>
                                                    <option value="flat" <?php echo e(old('discount_type')=='flat'?'selected':''); ?>>1 Year</option>
                                                    <option value="flat" <?php echo e(old('discount_type')=='flat'?'selected':''); ?>>2 Year</option>
                                                    <option value="flat" <?php echo e(old('discount_type')=='flat'?'selected':''); ?>>3 Year</option>
                                                    <option value="flat" <?php echo e(old('discount_type')=='flat'?'selected':''); ?>>5 Year</option>
                                                    <option value="flat" <?php echo e(old('discount_type')=='flat'?'selected':''); ?>>10 Year</option>
                                                    <option value="flat" <?php echo e(old('discount_type')=='flat'?'selected':''); ?>>Life Time</option>
                                                </select>
                                                <?php $__errorArgs = ['base_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="tab-pane text-muted" id="services-vertical-link" role="tabpanel">
                                        <div class="row">
                                            <div class="col-md-6 mb-2">
                                                <label for="discount_type" class="form-label">Discount Type</label>
                                                <select name="discount_type" id="discount_type" class="form-select">
                                                    <option value="">Select Type</option>
                                                    <option value="percentage" <?php echo e(old('discount_type')=='percentage'?'selected':''); ?>>Percentage</option>
                                                    <option value="flat" <?php echo e(old('discount_type')=='flat'?'selected':''); ?>>Flat</option>
                                                </select>
                                            </div>
                                            <div class="col-md-6 mb-2">
                                                <label for="discount_amount" class="form-label">Amount</label>
                                                <input type="number" class="form-control form-control-sm" id="discount_amount" name="discount_amount" value="<?php echo e(old('discount_amount')); ?>">
                                            </div>
                                            <div class="col-md-6 mb-2">
                                                <label for="discount_start" class="form-label">Start Date</label>
                                                <input type="date" class="form-control" id="discount_start" name="discount_start" value="<?php echo e(old('discount_start')); ?>">
                                            </div>
                                            <div class="col-md-6 mb-2">
                                                <label for="discount_end" class="form-label">End Date</label>
                                                <input type="date" class="form-control" id="discount_end" name="discount_end" value="<?php echo e(old('discount_end')); ?>">
                                            </div>
                                            <!-- Discount Status -->
                                            <div class="mt-4 border-top pt-3">
                                                <div class="form-check form-switch">
                                                    <input class="form-check-input" name="discount_status" type="checkbox" id="discountStatusToggle">
                                                    <label class="form-check-label" for="discountStatusToggle">Enable Discount</label>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="tab-pane text-muted" id="about-vertical-link" role="tabpanel">
                                        <!-- Weight -->
                                        <div class="mb-2">
                                            <label for="weight" class="form-label">Weight (kg)</label>
                                            <input type="number" class="form-control" id="weight" name="weight" value="<?php echo e(old('weight', 0)); ?>" step="0.01" min="0">
                                            <?php $__errorArgs = ['weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="border p-1 mb-2 bg-light">
                                            <label class="form-label mb-2 d-block">Dimensions (cm)</label>
                                            <div class="row g-2">
                                                <div class="col-md-4">
                                                    <input type="number" class="form-control" id="length" name="length" placeholder="Length" value="<?php echo e(old('length')); ?>" step="0.01" min="0">
                                                </div>
                                                <div class="col-md-4">
                                                    <input type="number" class="form-control" id="width" name="width" placeholder="Width" value="<?php echo e(old('width')); ?>" step="0.01" min="0">
                                                </div>
                                                <div class="col-md-4">
                                                    <input type="number" class="form-control" id="height" name="height" placeholder="Height" value="<?php echo e(old('height')); ?>" step="0.01" min="0">
                                                </div>
                                            </div>
                                            <?php if($errors->has('length') || $errors->has('width') || $errors->has('height')): ?>
                                                <div class="text-danger mt-1">Please check all dimension fields.</div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="row">
                                            <div class="col-6">
                                                <label class="form-label">Shipping Class</label>
                                                <select id="shipping_class" class="form-select">
                                                    <option value="">Select Shipping Class</option>
                                                    <?php $__currentLoopData = $shippingClasses ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($class->id); ?>" data-inside="<?php echo e($class->inside_rate); ?>" data-outside="<?php echo e($class->outside_rate); ?>"
                                                            <?php echo e(old('shipping_class') == $class->id ? 'selected' : ''); ?>>
                                                            <?php echo e($class->name); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="col-3">
                                                <label class="form-label">Inside City Rate</label>
                                                <input type="text" id="inside_rate_display" class="form-control form-control-sm" readonly>
                                            </div>
                                            <div class="col-3">
                                                <label class="form-label">Outside City Rate</label>
                                                <input type="text" id="outside_rate_display" class="form-control form-control-sm" readonly>
                                            </div>
                                        </div>

                                        <script>
                                            const s=document.getElementById('shipping_class'),i=document.getElementById('inside_rate_display'),o=document.getElementById('outside_rate_display');
                                            function u(){const e=s.selectedOptions[0];i.value=`৳ ${e?.dataset.inside||0}`,o.value=`৳ ${e?.dataset.outside||0}`}
                                            s.addEventListener('change',u),u();
                                        </script>
                                    </div>
                                    <div class="tab-pane text-muted" id="contacts-vertical-link" role="tabpanel">
                                        <div class="mb-1">
                                            <label for="meta_title" class="form-label">Meta Title</label>
                                            <input type="text" class="form-control" id="meta_title" name="meta_title" value="<?php echo e(old('meta_title')); ?>">
                                            <?php $__errorArgs = ['meta_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="mb-1">
                                            <label for="meta_description" class="form-label">Meta Description</label>
                                            <textarea class="form-control" id="meta_description" name="meta_description" rows="2"><?php echo e(old('meta_description')); ?></textarea>
                                            <?php $__errorArgs = ['meta_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="mb-1">
                                            <label for="meta_keywords" class="form-label">Meta Keywords</label>
                                            <input type="text" class="form-control" id="meta_keywords" name="meta_keywords" value="<?php echo e(old('meta_keywords')); ?>" placeholder="Separate keywords with commas">
                                            <?php $__errorArgs = ['meta_keywords'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Product Variants -->
                <div class="card custom-card">
                    <div class="card-header">
                        <div class="card-title">Product Variants Preview</div>
                    </div>

                    <div class="card-body">
                        <div class="row mb-3">
                            <div class="col-md-4">
                                <label class="form-label">Attributes</label>
                                <select name="attribute_id[]" id="attribute_id" class="form-select" multiple>
                                    <?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($attribute->id); ?>"><?php echo e($attribute->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            
                        </div>

                        <div id="attribute_items_container" class="row"></div>

                        <div id="variant_combinations_container"></div>
                    </div>
                </div>

                <?php $__env->startPush('css'); ?>
                <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/choices.js/public/assets/styles/choices.min.css" />
                <?php $__env->stopPush(); ?>

                <?php $__env->startPush('js'); ?>
                <script src="https://cdn.jsdelivr.net/npm/choices.js/public/assets/scripts/choices.min.js"></script>
                <script>
                    $(function() {

                        // Initialize Choices.js dropdowns
                        function initChoices() {
                            const makeChoice = (el) => new Choices(el, {
                                removeItemButton: true,
                                searchEnabled: true,
                                placeholderValue: 'Select Items'
                            });

                            if (!$('#attribute_id').data('choices-initialized')) {
                                makeChoice('#attribute_id');
                                $('#attribute_id').data('choices-initialized', true);
                            }

                            $('.attribute-item').each(function() {
                                if (!$(this).data('choices-initialized')) {
                                    makeChoice(this);
                                    $(this).data('choices-initialized', true);
                                }
                            });
                        }


                        // Load attribute items (e.g. Color, Size options)
                        function loadAttributeItems() {
                            let selected = $('#attribute_id').val();
                            if (!selected || selected.length === 0) {
                                $('#attribute_items_container').html('');
                                $('#variant_combinations_container').html('');
                                return;
                            }

                            $.get('<?php echo e(route("attributes.getItems")); ?>', { attribute_ids: selected }, function(html) {
                                $('#attribute_items_container').html(html);
                                initChoices();
                            });
                        }

                        // Load variant combinations (SKU generation)
                        function loadVariantCombinations() {
                            let attrs = [];
                            $('.attribute-item').each(function() {
                                let id = $(this).data('id');
                                let items = $(this).val();
                                if (items && items.length) attrs.push({ id, items });
                            });

                            $.ajax({
                                url: '<?php echo e(route("products.getItemsCombo")); ?>',
                                method: 'GET',
                                data: {
                                    sku_prefix: $('#sku_prefix').val(),
                                    price: $('#price').val(),
                                    purchase_price: $('#purchase_price').val(),
                                    attributes: attrs
                                },
                                success: function(html) {
                                    $('#variant_combinations_container').html(html);
                                }
                            });
                        }

                        // ✅ NEW: Dynamically show file inputs for color/image attributes
                        function updateImageUploadFields() {
                            $('.attribute-item').each(function() {
                                let hasImage = $(this).data('has-image'); // detect attribute with images (Color)
                                if (!hasImage) return;

                                let attrId = $(this).data('id');
                                let selectedItems = $(this).find('option:selected');
                                let container = $('.image-upload-container[data-attr-id="' + attrId + '"] .image-upload-fields');

                                container.html(''); // Clear previous fields

                                selectedItems.each(function() {
                                    let itemId = $(this).val();
                                    let itemName = $(this).text();

                                    // Add file upload input per selected item
                                    let fieldHtml = `
                                        <div class="d-flex align-items-center mb-2 single-upload-field" data-item-id="${itemId}">
                                            <span class="me-2 fw-semibold text-secondary" style="min-width:80px">${itemName}</span>
                                            <input type="file" name="attribute_images[${attrId}][${itemId}]" class="form-control form-control-sm" accept="image/*">
                                        </div>
                                    `;
                                    container.append(fieldHtml);
                                });
                            });
                        }

                        // --------------------
                        // Event Bindings
                        // --------------------
                        $('#attribute_id').on('change', loadAttributeItems);

                        // When user selects attribute items (e.g., colors or sizes)
                        $(document).on('change', '.attribute-item', function() {
                            loadVariantCombinations();
                            updateImageUploadFields(); // 👈 Add this
                        });

                        // When SKU or Price changes, refresh variant combinations
                        $(document).on('keyup change', '#sku_prefix,#price,#purchase_price', loadVariantCombinations);

                        // Remove variant row
                        $(document).on('click', '.remove-variant', function() {
                            $(this).closest('tr').remove();
                        });

                        // Initialize on page load
                        initChoices();
                    });
                    </script>

                <?php $__env->stopPush(); ?>

                


                
            </div>

            <!-- Right Column: Categories + Brands + Tags + Settings -->
            <div class="col-md-4">
                <!-- Product Categories -->
                <div class="card custom-card">
                    <div class="card-header justify-content-between">
                        <div class="card-title">Categories</div>
                        <a href="#" class="btn btn-primary-light btn-sm"><i class="bi bi-plus-lg"></i> Add New</a>
                    </div>
                    <div class="card-body pt-1">
                        <label for="category_id" class="form-label">Category <span class="text-danger">*</span></label>
                        <select name="category_id" id="category_id" class="form-select" required>
                            <option value="">Select Category</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>" <?php echo e(old('category_id')==$category->id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <!-- Product Brand -->
                <div class="card custom-card">
                    <div class="card-header justify-content-between">
                        <div class="card-title">Brands</div>
                        <a href="#" class="btn btn-primary-light btn-sm"><i class="bi bi-plus-lg"></i> Add New</a>
                    </div>
                    <div class="card-body pt-1">
                        <label for="brand_id" class="form-label">Brand</label>
                        <select name="brand_id" id="brand_id" class="form-select">
                            <option value="">Select Brand</option>
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($brand->id); ?>" <?php echo e(old('brand_id')==$brand->id ? 'selected' : ''); ?>><?php echo e($brand->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['brand_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <!-- Product Tag -->
                <div class="card custom-card">
                    <div class="card-header justify-content-between">
                        <div class="card-title">Tags</div>
                        <a href="#" class="btn btn-primary-light btn-sm"><i class="bi bi-plus-lg"></i> Add New</a>
                    </div>
                    <div class="card-body pt-1">
                        <label for="brand_id" class="form-label">Tag</label>
                        <select name="brand_id" id="brand_id" class="form-select">
                            <option value="">Select Tag</option>
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($brand->id); ?>" <?php echo e(old('brand_id')==$brand->id ? 'selected' : ''); ?>><?php echo e($brand->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['brand_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <!-- Settings -->
                <div class="card custom-card mt-3">
                    <div class="card-header">
                        <div class="card-title">Settings</div>
                    </div>
                    <div class="card-body">
                        <div class="mb-1">
                            <label for="product_type" class="form-label">Product Type</label>
                            <select class="form-select" id="product_type" name="product_type">
                                <option value="sale" <?php echo e(old('product_type',1)==1?'selected':''); ?>>Sale</option>
                                <option value="hot" <?php echo e(old('product_type',1)==0?'selected':''); ?>>Hot</option>
                                <option value="regular" <?php echo e(old('product_type',1)==0?'selected':''); ?>>Regular</option>
                                <option value="trending" <?php echo e(old('product_type',1)==0?'selected':''); ?>>Trending</option>
                            </select>
                        </div>
                        <div class="mb-1">
                            <label for="visibility" class="form-label">Visibility</label>
                            <select class="form-select" id="visibility" name="visibility">
                                <option value="public" <?php echo e(old('visibility',1)==1?'selected':''); ?>>Public</option>
                                <option value="private" <?php echo e(old('visibility',1)==0?'selected':''); ?>>Private</option>
                                <option value="schedule" <?php echo e(old('visibility',1)==0?'selected':''); ?>>Schedule</option>
                            </select>
                        </div>
                        <div class="mb-1">
                            <label for="status" class="form-label">Status</label>
                            <select class="form-select" id="status" name="status">
                                <option value="1" <?php echo e(old('status',1)==1?'selected':''); ?>>Active</option>
                                <option value="0" <?php echo e(old('status',1)==0?'selected':''); ?>>Inactive</option>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Actions -->
                <div class="card custom-card mt-3">
                    <div class="card-body">
                        <button type="submit" class="btn btn-primary w-100">Save Product</button>
                        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary w-100 mt-2">Cancel</a>
                    </div>
                </div>

            </div>
        </div>
    </form>

    <!-- JS for variants -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const addVariantBtn = document.getElementById('add-variant');
            const variantsContainer = document.getElementById('variants-container');
            const variantTemplate = document.getElementById('variant-template').content;

            addVariantBtn.addEventListener('click', () => {
                const clone = variantTemplate.cloneNode(true);
                variantsContainer.appendChild(clone);
            });

            variantsContainer.addEventListener('click', (e) => {
                if (e.target.classList.contains('remove-variant') || e.target.closest('.remove-variant')) {
                    e.target.closest('.variant-item').remove();
                }
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala2edde5e1c82a5de5f92a34d70a8fe30)): ?>
<?php $attributes = $__attributesOriginala2edde5e1c82a5de5f92a34d70a8fe30; ?>
<?php unset($__attributesOriginala2edde5e1c82a5de5f92a34d70a8fe30); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala2edde5e1c82a5de5f92a34d70a8fe30)): ?>
<?php $component = $__componentOriginala2edde5e1c82a5de5f92a34d70a8fe30; ?>
<?php unset($__componentOriginala2edde5e1c82a5de5f92a34d70a8fe30); ?>
<?php endif; ?>
<?php /**PATH D:\xampp8\htdocs\shop.skytechsolve.com\resources\views/backend/products/index.blade.php ENDPATH**/ ?>